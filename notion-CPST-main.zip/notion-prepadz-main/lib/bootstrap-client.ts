export function bootstrap() {
  console.log(`Made with ❤ by Mounib`)
}
