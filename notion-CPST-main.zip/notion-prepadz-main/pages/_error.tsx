import { ErrorPage } from 'components'

export default ErrorPage
